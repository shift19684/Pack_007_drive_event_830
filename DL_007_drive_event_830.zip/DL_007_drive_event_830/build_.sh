#!/bin/sh

sudo git clone https://github.com/shift19684/Pack_007_drive_event_830.git
sudo unzip ./Pack_007_drive_event_830/builder.zip
sudo rm ./Pack_007_drive_event_830/builder.zip 


sudo docker build -t 007_drive_event_830 -f ./builder/dockerfile .
sudo rm ./builder/connect.py
sudo rm ./builder/dockerfile

sudo rm -- "$0"
echo "finished building"
