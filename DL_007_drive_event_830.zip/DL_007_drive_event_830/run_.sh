#!/bin/sh

sudo docker run -it --rm 007_drive_event_830 