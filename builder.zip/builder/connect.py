from awsiot import mqtt_connection_builder
from awscrt import mqtt

import time
from datetime import datetime, timezone, timedelta
import sys
import json


TRIP_ID = int(time.time() * 1000)

ENDPOINT = "dxi-iot-endpoint.cvda.qa-ph3.dconnect2.daihatsu.co.jp"
CLIENT_ID = "SHIFT830-dcm18"
CLIENT_ID_2 = "SHIFT830-hcu18"

#TOPIC="dt/dxi/emergency/SHIFT830-dcm18/request"

PATH_TO_CERTIFICATE = "crt/crt/certificate.pem.crt"
PATH_TO_PRIVATE_KEY = "crt/crt/private.pem.key"
PATH_TO_AMAZON_ROOT_CA_1 = "crt/crt/aws-ca.pem"

PATH_TO_CERTIFICATE_2 = "crt/crt2/certificate.pem.crt"
PATH_TO_PRIVATE_KEY_2 = "crt/crt2/private.pem.key"
PATH_TO_AMAZON_ROOT_CA_2 = "crt/crt2/aws-ca.pem"


TOPIC_1 = "dt/dxi/telemetry/SHIFT830-hcu18/eco_trip_tel"
TOPIC_2 = "dt/dxi/telemetry/SHIFT830-hcu18/drive_behavior_upd"
TOPIC_3 = "dt/dxi/telemetry/SHIFT830-dcm18/event"


TIME_OFFSET = 9 #hours UTC+9 time offset

# Standard Retry
RETRIES = 3 #times
INTERVAL = 9 #seconds
TIMEOUT = 10 #seconds

# Custom Retry
C_RETRIES = 10 #times
C_INTERVAL = 60 #seconds
C_TIMEOUT = 10 #seconds


# Create a +9 hour offset
jst_tz = timezone(timedelta(hours=TIME_OFFSET))

TIMESTAMP = int(time.time() * 1000)

MESSAGE_1 = {
    "owner_g_sys_user_id": "57340af8-1041-7072-3e88-bbe7e0ef2e7d",
    "vin": "LA851S-AB00133",
    "hcu_serial_number": "SHIFT830-hcu18",
    "timestamp": TIMESTAMP,
    "trip_id": TRIP_ID,
    "trip_to_fc": 10,
    "trip_mileage": 10,
    "trip_time": 60,
    "privacy_mode": 0
}
#

MESSAGE_2 = {
    "owner_g_sys_user_id": "57340af8-1041-7072-3e88-bbe7e0ef2e7d",
    "vin": "LA851S-AB00133",
    "hcu_serial_number": "SHIFT830-hcu18",
    "timestamp": TIMESTAMP,
    "trip_id": TRIP_ID,
    "privacy_mode": 0,
    "profile_id": 0,
    "trip_monitoring_information": {
        "trip_long_distracted_driving_count": 0,
        "trip_short_distracted_driving_count": 0,
        "trip_drowsy_driving_count": 0,
        "trip_average_heart_rate": 0,
        "trip_minimum_heart_rate": 0,
        "trip_maximum_heart_rate": 0
    },
    "drive_report_status_trip": {
        "trip_total_score": 0,
        "trip_accelerator_score": 0,
        "trip_brake_score": 0,
        "trip_handle_score": 0,
        "trip_driving_manner_score": 0,
        "trip_safety_confirm_score": 0,
        "trip_traffic_rules_score": 0,
        "trip_advice": "アドバイス"
    }
}


MESSAGE_3 = {
    "owner_g_sys_user_id": "57340af8-1041-7072-3e88-bbe7e0ef2e7d",
    "vin": "LA851S-AB00133",
    "dcm_serial_number": "SHIFT830-dcm18",
    "timestamp": TIMESTAMP,
    "longitude": 138.25344,
    "latitude": 36.20782,
    "accuracy": 1.7,
    "altitude": 0,
    "altitude_accuracy": 10.3,
    "trip_id": TRIP_ID,
    "event_id": "102",
    "privacy_mode": 0,
    "trip_fcw": 10,
    "trip_aeb": 3,
    "trip_fr_pmp": 7,
    "trip_rr_pmp": 9,
    "trip_ldw": 0,
    "trip_tmn": 6
    }


PAYLOAD_1 = json.dumps(MESSAGE_1)
PAYLOAD_2 = json.dumps(MESSAGE_2)
PAYLOAD_3 = json.dumps(MESSAGE_3)


# Check Availability
#
limit = datetime(2026,5,30,10,0)
current = datetime.now() # no time offset
#
sys.stdout.write(f"\n")
print("time : ", datetime.now(jst_tz))
#
if current > limit:
    print("beyond limit")
    sys.exit()
else:
    print("entering program") 
#
#
#
# connection builder
#
mqtt_connection = mqtt_connection_builder.mtls_from_path(
    endpoint=ENDPOINT,
    cert_filepath=PATH_TO_CERTIFICATE,
    pri_key_filepath=PATH_TO_PRIVATE_KEY,
    ca_filepath=PATH_TO_AMAZON_ROOT_CA_1,
    client_id=CLIENT_ID,
    clean_session=False,
    keep_alive_secs=120
)
#
#
mqtt_connection_2 = mqtt_connection_builder.mtls_from_path(
    endpoint=ENDPOINT,
    cert_filepath=PATH_TO_CERTIFICATE_2,
    pri_key_filepath=PATH_TO_PRIVATE_KEY_2,
    ca_filepath=PATH_TO_AMAZON_ROOT_CA_2,
    client_id=CLIENT_ID_2,
    clean_session=False,
    keep_alive_secs=120
)

# Connecting
#
connect_future = mqtt_connection.connect()
connect_future_2 = mqtt_connection_2.connect()
#
print("time : ", datetime.now(jst_tz))
#
# result() waits until a result is available
connect_future.result()
#
print("MESSAGE No. 1:")
print(PAYLOAD_1)
print("MESSAGE No. 2:")
print(PAYLOAD_2)
print("MESSAGE No. 3:")
print(PAYLOAD_3)
#
print(f'{CLIENT_ID} is connected to AWS')
print(TOPIC_1)
print(TOPIC_2)
print(TOPIC_3)
#Simple pause
input("Press ENTER to publish ... ")
#
#
#
# Publishing 
#
#
print("time : ", datetime.now(jst_tz))
print(f"Publishing to TOPICs ...")
#
#
# Standard Retry
#
attempt = 1
while attempt <= RETRIES+1:
    try:
        #
        start_time = time.time()
        #
        print("time : ", datetime.now(jst_tz))
        print(f"Standard Attempt to publish : Attempt no. {attempt} : Retry no. {attempt-1}")
        #
        
        publish_future_1, packet_id_1 = mqtt_connection_2.publish(
             topic=TOPIC_1,
             payload=PAYLOAD_1,
             qos=mqtt.QoS.AT_LEAST_ONCE
        )
        #
        
        publish_future_2, packet_id_2 = mqtt_connection_2.publish(
             topic=TOPIC_2,
             payload=PAYLOAD_2,
             qos=mqtt.QoS.AT_LEAST_ONCE
        )
        
        #
        publish_future_3, packet_id_3 = mqtt_connection.publish(
             topic=TOPIC_3,
             payload=PAYLOAD_3,
             qos=mqtt.QoS.AT_LEAST_ONCE
        )
        
        #
        while not publish_future_3.done():
            elapsed = time.time() - start_time
            # \r returns the cursor to the start of the line to overwrite it
            sys.stdout.write(f"\rStandard Sending ... Elapsed time: {elapsed:.2f} seconds")
            sys.stdout.flush()
            time.sleep(0.05)
            if elapsed > TIMEOUT:
                sys.stdout.write(f"\n")
                raise TimeoutError("Standard Publish operation timed out.")
        #
        #
        sys.stdout.write(f"\n")
        #
        res_1 = publish_future_1.result(timeout=TIMEOUT)
        res_2 = publish_future_2.result(timeout=TIMEOUT)
        res_3 = publish_future_3.result(timeout=C_TIMEOUT)
        #
        print("time : ", datetime.now(jst_tz))
        print(f"Standard Attempt no. {attempt} : Standard Retry no. {attempt-1}")
        #print(f"Message {res} published successfully to topic : ")
        print(f"Message published successfully to topics : ")
        print(TOPIC_1)
        print("MESSAGE No. 1:")
        print(PAYLOAD_1)
        print(TOPIC_2)
        print("MESSAGE No. 2:")
        print(PAYLOAD_2)
        print(TOPIC_3)
        print("MESSAGE No. 3:")
        print(PAYLOAD_3)
        # Final result
        total_time = time.time() - start_time
        print(f"Total time: {total_time:.4f} seconds")
        attempt = RETRIES+2
        #
        sys.exit()
        #
    except TimeoutError as e:
        #
        print("time : ", datetime.now(jst_tz))
        print(f"Timeout occurred: {e}")
        print(f"Timeout : Failed to Standard Publish : Attempt no. {attempt} : Retry no. {attempt-1}")
        #
        attempt += 1
        #
        if attempt <= RETRIES+1:
            print("time : ", datetime.now(jst_tz))
            print(f"Standard Attempt no. {attempt} : Standard Retry no. {attempt-1} : Retrying in {INTERVAL} seconds...")
            #time.sleep(INTERVAL)
            start_time = time.perf_counter()
            while True:
                elapsed = time.perf_counter() - start_time
                if elapsed >= INTERVAL:
                    break
                #
                # \r moves the cursor back to the start of the line
                # end="" prevents moving to a new line
                print(f"\rWaiting time: {elapsed:.2f} seconds", end="", flush=True)
                time.sleep(1.0)
            #
            sys.stdout.write(f"\n")
            #
        if attempt > RETRIES+1:
            print("time : ", datetime.now(jst_tz))
            print(f"*\nMaximum Standard RETRY reached. Timeout : Standard Publication failed.\n*")
        #
        #


#
#
# Custom Retry
#
#
attempt = 2
while attempt <= C_RETRIES+1:
    try:
        #
        start_time = time.time()
        #
        print("time : ", datetime.now(jst_tz))
        print(f"Custom Retry to publish : Retry no. {attempt-1}")
        # publish returns a tuple (future, packet_id)
        publish_future, packet_id = mqtt_connection.publish(
             topic=TOPIC_3,
             payload=PAYLOAD_3,
             qos=mqtt.QoS.AT_LEAST_ONCE
        )
        #
        #Wait for publication to succeed
        #publish_future.result(timeout=5.0)
        #
        #
        while not publish_future.done():
            elapsed = time.time() - start_time
            # \r returns the cursor to the start of the line to overwrite it
            sys.stdout.write(f"\rCustom Sending ... Elapsed time: {elapsed:.2f} seconds")
            sys.stdout.flush()
            time.sleep(0.05)
            if elapsed > C_TIMEOUT:
                sys.stdout.write(f"\n")
                raise TimeoutError("Custom Publish operation timed out.")
        #
        #
        sys.stdout.write(f"\n")
        res = publish_future.result(timeout=C_TIMEOUT)
        #
        #
        print("time : ", datetime.now(jst_tz))
        print(f"Custom Retry no. {attempt-1}")
        print(f"Message {res} published successfully to topic : ")
        print(TOPIC_3)
        print("MESSAGE No. 3:")
        print(PAYLOAD_3)
        # Final result
        total_time = time.time() - start_time
        print(f"Total time: {total_time:.4f} seconds")
        attempt = C_RETRIES+2
        #    
    except TimeoutError as e:
        #
        print("time : ", datetime.now(jst_tz))
        print(f"Timeout occurred: {e}")
        print(f"Timeout : Failed to Custom Publish : Retry no. {attempt-1}")
        #
        attempt += 1
        #
        if attempt <= C_RETRIES+1:
            print("time : ", datetime.now(jst_tz))
            print(f"Custom Retry no. {attempt-1} : Retrying in {C_INTERVAL} seconds...")
            start_time = time.perf_counter()
            while True:
                elapsed = time.perf_counter() - start_time
                if elapsed >= C_INTERVAL:
                    break
                #
                # \r moves the cursor back to the start of the line
                # end="" prevents moving to a new line
                print(f"\rWaiting time: {elapsed:.2f} seconds", end="", flush=True)
                time.sleep(1.0)
            #
            sys.stdout.write(f"\n")
            #
        if attempt > C_RETRIES+1:
            print("time : ", datetime.now(jst_tz))
            print(f"*\nMaximum Custom RETRY reached. Timeout : Custom Publication failed.\n*")
        #
        #

